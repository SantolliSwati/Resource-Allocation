export const resources = [
  {
    resourceId: "R001",
    resourceName: "John Doe",
    skills: ["React", "Node.js", "TypeScript"],
    experience: 5
  },
  {
    resourceId: "R002",
    resourceName: "Jane Smith",
    skills: ["Python", "Django", "AWS"],
    experience: 3
  },
  {
    resourceId: "R003",
    resourceName: "Mike Johnson",
    skills: ["Java", "Spring", "Kubernetes"],
    experience: 7
  },
  {
    resourceId: "R004",
    resourceName: "Sarah Williams",
    skills: ["React", "Vue.js", "JavaScript"],
    experience: 4
  },
  {
    resourceId: "R005",
    resourceName: "David Brown",
    skills: ["Angular", "Node.js", "MongoDB"],
    experience: 6
  }
];